This directory will beautomatically populated with files using the JAR resolver.
