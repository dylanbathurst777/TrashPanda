﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Sirenix.OdinInspector;
using Sirenix.Serialization;

public class BuildingDamage : SerializedMonoBehaviour 
{

    public float maxHealth = 100;
    public float curretHeath;

    public Image healthBar;
    public DamageText damageText;

    [OdinSerialize]
    private Dictionary<DamageType, float> resistances;

    // Use this for initialization
    void Start () {
        curretHeath = maxHealth;
        damageText = GetComponentInChildren<DamageText>();
    }
	
	// Update is called once per frame
	void Update () {
		
	}
    public void TakeDamage(int amount, DamageType damageType)
    {

        float resistance = resistances[damageType];
        float resistanceMultiplier = resistance / 100f;
        int modifiedAmount = (int)((float)amount * resistanceMultiplier);
        curretHeath -= modifiedAmount;
        healthBar.fillAmount = curretHeath / maxHealth;
        if (curretHeath <= 0)
        {
          
            Destroy(gameObject);


        }

        damageText.ShowDamage(modifiedAmount, damageType);
    }
}
