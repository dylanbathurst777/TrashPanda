﻿

	public enum DamageType
    {
        Range,
        Physical,
        Enviroment,
    }

