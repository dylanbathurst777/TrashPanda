﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
using UnityEngine.UI;

public class UIM : MonoBehaviour {

    public GoogleAnalyticsV4 googleAnalytics;
    [SerializeField]
    public GameObject CurrentselectedWall;
    [SerializeField]
    public GameObject UpgradewallCurrentselectedWall;

    [SerializeField]
    public int CurrentWallLevel;


    public Image deactivatedHouse;
    public Image deactivatedWall;
    public Image deactivatedGate;
    public Image deactivatedRangeUnit;
    public Image deactivatedMeleeUnit;
    public Image deactivatedFarmUnit;
    public Image deactivatedWallUpgrade;
    public bool GatheringMaster;

    public Button activatedHouse;
    public Button activatedWall;
    public Button activatedGate;
    public Button activatedRangeUnit;
    public Button activatedMeleeUnit;
    public Button activatedFarmUnit;
    public Button activatedWallUpgrade;

    public Button SendFarmersToGather;
    public Button StopFarmersToGather;


    public Text CurrencyText;
    public int CurrencyTotal;
    public int HouseCost = -20;
    public int WallCost = -5;
    public int GateCost = -50;
    public int RangeUnit = -15;
    public int MeleeUnit = -25;
    public int FarmerUnit = -5;
    //WallUpgrade Costs
    public int Level1Cost = -10;
    public int Level2Cost = -20;
   

    public PlayerFarmer playerfarm;




    // Main Menu


    public void Awake()
    {
        googleAnalytics = FindObjectOfType<GoogleAnalyticsV4>();
    }
        public void Start()
    {




        googleAnalytics.GetComponent<GoogleAnalyticsV4>().LogEvent("LocationViewing", "TheMainMenu", "Viewing", 1);

        





       




    }
    void LateUpdate()
    {
        
    }
    void FixedUpdate()
    {

        CurrencyUpdate();




    }
    
       
    
    public void CurrencyUpdate()
    {
        CurrencyText.text = "Scrap:" + CurrencyTotal.ToString();
        if (CurrencyTotal < 50 && activatedGate)
        {
            activatedGate.gameObject.SetActive(false);
            deactivatedGate.gameObject.SetActive(true);
        }
        else
        {
            activatedGate.gameObject.SetActive(true);
            deactivatedGate.gameObject.SetActive(false);
        }
        if (CurrencyTotal < 25 && activatedMeleeUnit)
        {
            activatedMeleeUnit.gameObject.SetActive(false);
            deactivatedMeleeUnit.gameObject.SetActive(true);
        }
        else
        {
            activatedMeleeUnit.gameObject.SetActive(true);
            deactivatedMeleeUnit.gameObject.SetActive(false);
        }
        if (CurrencyTotal < 20 && activatedHouse)
        {
            activatedHouse.gameObject.SetActive(false);
            deactivatedHouse.gameObject.SetActive(true);
        }
        else
        {
            activatedHouse.gameObject.SetActive(true);
            deactivatedHouse.gameObject.SetActive(false);
        }
        if (CurrencyTotal < 15 && activatedRangeUnit)
        {
            activatedRangeUnit.gameObject.SetActive(false);
            deactivatedRangeUnit.gameObject.SetActive(true);
        }
        else
        {
            activatedRangeUnit.gameObject.SetActive(true);
            deactivatedRangeUnit.gameObject.SetActive(false);
        }

        if (CurrencyTotal < 5 && activatedWall)
        {
            activatedWall.gameObject.SetActive(false);
            deactivatedWall.gameObject.SetActive(true);
            activatedFarmUnit.gameObject.SetActive(false);
            deactivatedFarmUnit.gameObject.SetActive(true);
        }
        else
        {
            activatedFarmUnit.gameObject.SetActive(true);
            deactivatedFarmUnit.gameObject.SetActive(false);
            activatedWall.gameObject.SetActive(true);
            deactivatedWall.gameObject.SetActive(false);
        }

        if (CurrencyTotal <= 999)
        {
            CurrencyText.text = "Scrap:0" + CurrencyTotal.ToString();
        }
        if (CurrencyTotal <= 99)
        {
            CurrencyText.text = "Scrap:00" + CurrencyTotal.ToString();
        }
        if (CurrencyTotal <= 9)
        {
            CurrencyText.text = "Scrap:000" + CurrencyTotal.ToString();
        }
    }
    public void GatheringIsActive()
    {
        GatheringMaster = true;
    }
    public void GatheringIsNotActive()
    {
        GatheringMaster = false;
    }

    public void PlayGame()
    {
        
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
       
        googleAnalytics.LogEvent("Load", "Level_1", "Playing", 1);

     
     

         // Builder Hit with all Timing parameters.
        googleAnalytics.GetComponent<GoogleAnalyticsV4>().LogTiming(new TimingHitBuilder()
            .SetTimingCategory("Loading")
            .SetTimingInterval(50L)
            .SetTimingName("Level_1")
            .SetTimingLabel("First load")); 
    }

    public void QuitGame()
    {
      /*  googleAnalytics.LogEvent("LocationViewing", "HasViewed", "Quit", 1);
        googleAnalytics.LogEvent(new EventHitBuilder()
     .SetEventCategory("LocationViewing")
     .SetEventAction("HasViewed")
    .SetEventLabel("QuitGame")
     .SetEventValue(1));*/
        Debug.Log("Quit");
        googleAnalytics.GetComponent<GoogleAnalyticsV4>().LogEvent("QuitGame", "QuitPressed", "Quit", 1);
        Application.Quit();
      
    }

    // Sound

    public AudioMixer audioMixer;

    public void SetVolume(float volume)
    {
        audioMixer.SetFloat("volume", volume);
    }

    // Graphics

    public void SetQuality (int qualityIndex)
    {
        QualitySettings.SetQualityLevel(qualityIndex);
    }

    // Fullscreen

    public void SetFullscreen (bool isFullscreen)
    {
        if (isFullscreen)
        {
            Screen.fullScreenMode = FullScreenMode.ExclusiveFullScreen;
        }
        else
        {
            Screen.fullScreenMode = FullScreenMode.Windowed;
        }
    }

    // Restart Menu

    public GameObject RestartMenu;
    
    public void Restart()

    {

        SceneManager.LoadScene("Level_1");

    }

    // Pause Menu

    public static bool GameIsPaused = false;

    public GameObject pauseMenuUI;

    void Update()
    {
        if (CurrentWallLevel == 0)
        {
            activatedWallUpgrade.gameObject.SetActive(false);
            deactivatedWallUpgrade.gameObject.SetActive(true);
        }
        else
        {
            activatedWallUpgrade.gameObject.SetActive(true);
            deactivatedWallUpgrade.gameObject.SetActive(false);
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (GameIsPaused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }

        // Restart Menu if:
       

        /*if (Player1.Playerdeath || Player2.Playerdeath == true)
        {
            RestartMenu.SetActive(true);
        }
        else
        {
            RestartMenu.SetActive(false);
        }*/

    }

    public void Resume ()
    {
        pauseMenuUI.SetActive(false);
        Time.timeScale = 1f;
        GameIsPaused = false;
    }

    void Pause()
    {
        pauseMenuUI.SetActive(true);
        Time.timeScale = 0f;
        GameIsPaused = true;
    }

    public void LoadMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("C&C UI");
    }

    public void QuitGamePause()
    {
        Debug.Log("Quitting game...");
        Application.Quit();
    }

    public void UpgradingWall()
    {
        CurrentselectedWall = UpgradewallCurrentselectedWall;
       CurrentselectedWall.gameObject.GetComponent<UpgradeWall>().CurrentLevel = CurrentWallLevel;
      

        if (CurrentWallLevel == 1 && CurrencyTotal >= 10)
        {
            CurrencyTotal += Level1Cost;
            activatedWallUpgrade.gameObject.SetActive(true);
            deactivatedWallUpgrade.gameObject.SetActive(false);

        }
        else
        {
            activatedWallUpgrade.gameObject.SetActive(false);
            deactivatedWallUpgrade.gameObject.SetActive(true);
        }
        if (CurrentWallLevel == 2 && CurrencyTotal >= 20)
        {
            CurrencyTotal += Level2Cost;
            activatedWallUpgrade.gameObject.SetActive(true);
            deactivatedWallUpgrade.gameObject.SetActive(false);
        }
        else
        {
            activatedWallUpgrade.gameObject.SetActive(false);
            deactivatedWallUpgrade.gameObject.SetActive(true);
        }
        if (CurrentWallLevel == 3)
        {
            activatedWallUpgrade.gameObject.SetActive(false);
            deactivatedWallUpgrade.gameObject.SetActive(true);
        }
        if (CurrentWallLevel == 0)
        {
            activatedWallUpgrade.gameObject.SetActive(false);
            deactivatedWallUpgrade.gameObject.SetActive(true);
        }
        
    }


}
